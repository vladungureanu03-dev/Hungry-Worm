package Inputs;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import GameStates.GameState;
import Main.GamePanel;

/**
 * Listens for keyboard input and routes actions to the current active screen.
 */
public class KeyboardInputs implements KeyListener {

    private final GamePanel gamePanel;

    public KeyboardInputs(GamePanel gamePanel) {
        this.gamePanel = gamePanel;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        // Escape always returns to the main menu and clears button states.
        if (key == KeyEvent.VK_ESCAPE) {
            gamePanel.getGame().getSettings().resetButtons();
            gamePanel.getGame().getMenu().resetButtons();
            GameState.state = GameState.MENU;
            return;
        }

        // Space is used to start the game from the menu or restart after game over.
        if (key == KeyEvent.VK_SPACE) {
            if (GameState.state == GameState.MENU) {
                gamePanel.getGame().startGame();
                return;
            }
            if (GameState.state == GameState.GAME_OVER) {
                gamePanel.getGame().restartGame();
                return;
            }
        }

        // While playing, arrow keys and space are forwarded to the gameplay state.
        if (GameState.state == GameState.PLAYING) {
            gamePanel.getGame().getPlaying().handleKeyPress(key);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }
}
package GUI;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

/**
 * Utility class for loading sprite sheets and image assets.
 * It tries the classpath first and then a few project-relative fallbacks.
 */
public class LoadSave {

    public static final String MENU_BUTTONS = "menu_buttons.png";
    public static final String SETTINGS_BUTTONS = "settings_buttons.png";
    public static final String MENU_BACKGROUND = "menu_background.png";
    public static final String GRASS = "grass.png";

    /**
     * Loads an image from the resources folder, falling back to local filesystem paths.
     */
    public static BufferedImage GetSpriteAtlas(String fileName) {
        try (InputStream is = LoadSave.class.getResourceAsStream("/" + fileName)) {
            if (is != null) {
                return ImageIO.read(is);
            }
        } catch (IOException e) {
            throw new RuntimeException("Could not read " + fileName, e);
        }

        String[] candidates = {
                "Images/" + fileName,
                "../Images/" + fileName,
                "../../Images/" + fileName,
                fileName
        };

        for (String candidate : candidates) {
            java.io.File file = new java.io.File(candidate);
            if (file.exists()) {
                try {
                    return ImageIO.read(file);
                } catch (IOException e) {
                    throw new RuntimeException("Could not read " + fileName, e);
                }
            }
        }

        throw new RuntimeException("Resource not found on classpath or in project image folders: /" + fileName);
    }

    // to be revised
}

package GameStates;

import java.awt.Point;
import java.util.ArrayList;

/**
 * Represents the worm in the grid. The body is stored as a list of points,
 * where the first element is always the head.
 */
public class Worm {

    private final ArrayList<Point> body = new ArrayList<>();
    private Direction direction = Direction.RIGHT;

    public Worm() {
        reset();
    }

    /**
     * Resets the worm to its starting size and facing direction.
     */
    public void reset() {
        body.clear();
        direction = Direction.RIGHT;
        body.add(new Point(5, 5));
        body.add(new Point(4, 5));
        body.add(new Point(3, 5));
    }

    /**
     * Updates the current direction while preventing 180-degree reversals.
     */
    public void setDirection(Direction nextDir) {
        Direction current = direction;

        if ((current == Direction.UP && nextDir == Direction.DOWN)
                || (current == Direction.DOWN && nextDir == Direction.UP)
                || (current == Direction.LEFT && nextDir == Direction.RIGHT)
                || (current == Direction.RIGHT && nextDir == Direction.LEFT)) {
            return;
        }

        direction = nextDir;
    }

    /**
     * Calculates the next head position without moving the worm yet.
     */
    public Point getNextHead() {
        Point head = new Point(body.get(0));

        switch (direction) {
            case UP -> head.y--;
            case DOWN -> head.y++;
            case LEFT -> head.x--;
            case RIGHT -> head.x++;
        }

        return head;
    }

    /**
     * Moves the worm one tile forward by adding a new head and removing the tail.
     */
    public void move() {
        Point head = getNextHead();
        body.add(0, head);
        body.remove(body.size() - 1);
    }

    /**
     * Lets the worm grow by adding a new head without trimming the tail.
     */
    public void grow() {
        Point head = getNextHead();
        body.add(0, head);
    }

    public boolean contains(Point p) {
        return body.contains(p);
    }

    public Point getHead() {
        return body.get(0);
    }

    public ArrayList<Point> getBody() {
        return body;
    }

    public Direction getDirection() {
        return direction;
    }
}
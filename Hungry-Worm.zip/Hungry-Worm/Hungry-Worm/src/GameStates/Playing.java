package GameStates;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import Main.Game;

public class Playing extends State implements StateMethods {

    // Main game state references.
    private final Worm worm;
    private final List<Food> foods = new ArrayList<>();

    // Core rules of the game.
    private static final int MAX_LIVES = 3;
    private static final float HUNGER_MAX = 100f;
    private static final float HUNGER_GAIN_PER_SECOND = 5f;
    private static final float HUNGER_DROP_PER_APPLE = 30f;

    // Current game statistics and flags.
    private int score = 0;
    private int lives = MAX_LIVES;
    private float hunger = 0f;
    private boolean gameOver = false;
    private boolean started = false;
    private long lastMoveTime = 0;
    private long lastHungerUpdateTime = 0;
    private Rectangle restartButtonBounds;

    // These are loaded from the settings screen each time a new round begins.
    private int tileSize = 20;
    private int gridWidth = 30;
    private int gridHeight = 26;
    private long moveDelayNs = 150_000_000L;

    // Growth timing support for the worm's temporary size increase effect.
    private int pendingGrowth = 0;
    private long lastGrowTime = 0;
    private static final long GROW_DELAY_NS = 300_000_000L;

    public Playing(Game game) {
        super(game);
        worm = new Worm();
        resetGame();
    }

    // Resets the board to a fresh round and reapplies the player-selected settings.
    public void resetGame() {
        applySettings();
        score = 0;
        lives = MAX_LIVES;
        hunger = 0f;
        pendingGrowth = 0;
        lastGrowTime = 0;
        gameOver = false;
        started = false;
        lastMoveTime = System.nanoTime();
        lastHungerUpdateTime = System.nanoTime();
        worm.reset();
        worm.setDirection(Direction.RIGHT);
        for (Food f : foods) {
            f.respawn(worm, foods, gridWidth, gridHeight);
        }
        restartButtonBounds = new Rectangle(300, 390, 200, 50);
    }

    // Reads the current gameplay settings and rebuilds the food list for the new match.
    private void applySettings() {
        Settings.FieldSize field = Settings.getFieldSize();
        tileSize = field.tile;
        gridWidth = field.cols;
        gridHeight = field.rows;
        moveDelayNs = Settings.getWormSpeed().moveDelayNs;
        foods.clear();
        for (int i = 0; i < Settings.getAppleCount().apples; i++) {
            foods.add(new Food());
        }
    }

    // Handles clicks on the game-over restart button.
    public boolean handleRestartClick(int x, int y) {
        if (restartButtonBounds != null && restartButtonBounds.contains(x, y)) {
            game.getPlaying().resetGame();
            GameState.state = GameState.PLAYING;
            return true;
        }
        return false;
    }

    @Override
    public void update() {
        // If the game is over or the round has not started, nothing should advance.
        if (gameOver || !started) {
            return;
        }

        long now = System.nanoTime();

        // Hunger slowly climbs while the game is active and resets after losing a life.
        if (started) {
            long elapsedNs = now - lastHungerUpdateTime;
            if (elapsedNs > 0) {
                hunger = Math.min(HUNGER_MAX, hunger + (elapsedNs / 1_000_000_000.0f) * HUNGER_GAIN_PER_SECOND);
                lastHungerUpdateTime = now;
            }
        }

        // When hunger reaches its cap, the worm loses a life and resets its position.
        if (hunger >= HUNGER_MAX) {
            if (!loseLifeAndRespawn()) {
                return;
            }
            hunger = 0f;
            lastHungerUpdateTime = now;
            return;
        }

        // Food items that expire are re-spawned to keep the board active.
        for (Food food : foods) {
            if (food.shouldDespawn(now)) {
                food.respawn(worm, foods, gridWidth, gridHeight);
            }
        }

        // Movement is throttled so the worm doesn't move too quickly.
        if (now - lastMoveTime < moveDelayNs) {
            return;
        }

        lastMoveTime = now;

        // Detect whether the worm's next head position is on top of edible food.
        Point nextHead = worm.getNextHead();
        Food eatenFood = null;
        for (Food food : foods) {
            if (nextHead.equals(food.getPosition())) {
                eatenFood = food;
                break;
            }
        }

        if (eatenFood != null) {
            hunger = Math.max(0f, hunger - HUNGER_DROP_PER_APPLE);

            int foodValue = eatenFood.getValue();
            if (foodValue < 0) {
                // Poison apples are dangerous and immediately remove a life.
                if (!loseLifeAndRespawn()) {
                    return;
                }

                eatenFood.respawn(worm, foods, gridWidth, gridHeight);
                return;
            }

            // Safe food increases score and grows the worm.
            score += foodValue;
            worm.grow();
            eatenFood.respawn(worm, foods, gridWidth, gridHeight);
            return;
        }

        // Move the worm forward if no food was eaten.
        worm.move();

        // Hitting the arena boundary causes a life loss.
        if (worm.getHead().x < 0 || worm.getHead().x >= gridWidth
                || worm.getHead().y < 0 || worm.getHead().y >= gridHeight) {
            loseLifeAndRespawn();
            return;
        }

        // Running into your own body ends the round.
        for (int i = 1; i < worm.getBody().size(); i++) {
            if (worm.getHead().equals(worm.getBody().get(i))) {
                gameOver = true;
                GameState.state = GameState.GAME_OVER;
                return;
            }
        }
    }

    // Handles a life loss and resets the worm to its starting state.
    private boolean loseLifeAndRespawn() {
        lives--;
        if (lives <= 0) {
            gameOver = true;
            GameState.state = GameState.GAME_OVER;
            return false;
        }

        worm.reset();
        worm.setDirection(Direction.RIGHT);
        lastMoveTime = System.nanoTime();
        return true;
    }

    @Override
    public void draw(Graphics g) {
        // Center the playfield inside the game window.
        int offsetX = (Game.GAME_WIDTH - gridWidth * tileSize) / 2;
        int offsetY = (Game.GAME_HEIGHT - gridHeight * tileSize) / 2;

        // Draw the background grid.
        g.setColor(new Color(255, 255, 255, 100));
        for (int x = 0; x <= gridWidth; x++) {
            g.drawLine(offsetX + x * tileSize, offsetY,
                    offsetX + x * tileSize, offsetY + gridHeight * tileSize);
        }
        for (int y = 0; y <= gridHeight; y++) {
            g.drawLine(offsetX, offsetY + y * tileSize,
                    offsetX + gridWidth * tileSize, offsetY + y * tileSize);
        }

        // Draw the worm body.
        g.setColor(new Color(250, 148, 255));
        for (Point p : worm.getBody()) {
            g.fillRect(offsetX + p.x * tileSize, offsetY + p.y * tileSize,
                    tileSize, tileSize);
        }

        // Draw each food item using its color seed to represent regular, golden, or poisoned apples.
        for (Food food : foods) {
            switch (food.getSeed()) {
                case 1 -> g.setColor(Color.YELLOW); // Golden apple
                case 2, 3 -> g.setColor(Color.MAGENTA); // Poisoned apple
                default -> g.setColor(Color.RED); // Normal apple
            }
            Point f = food.getPosition();
            g.fillRect(offsetX + f.x * tileSize, offsetY + f.y * tileSize,
                    tileSize, tileSize);
        }

        // Draw the top HUD with score, lives, and hunger meter.
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 22));
        g.drawString("Score: " + score, 20, 30);
        g.drawString("Lives: " + lives, 20, 60);

        int meterW = 180;
        int meterX = Game.GAME_WIDTH - meterW - 20;
        int meterY = 10;
        int meterH = 18;
        g.setColor(new Color(50, 50, 50, 180));
        g.fillRoundRect(meterX, meterY, meterW, meterH, 10, 10);
        g.setColor(new Color(255, 170, 60));
        int fillW = (int) ((hunger / HUNGER_MAX) * meterW);
        g.fillRoundRect(meterX, meterY, fillW, meterH, 10, 10);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 14));
        int labelWidth = g.getFontMetrics().stringWidth("Hunger");
        g.drawString("Hunger", meterX - labelWidth - 8, meterY + 15);

        // When the game ends, cover the board and show the restart prompt.
        if (gameOver) {
            g.setColor(new Color(0, 0, 0, 180));
            g.fillRect(0, 0, Game.GAME_WIDTH, Game.GAME_HEIGHT);

            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 40));
            g.drawString("Game Over", 260, 270);

            g.setColor(new Color(70, 150, 255));
            g.fillRoundRect(300, 390, 200, 50, 20, 20);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 22));
            g.drawString("Restart", 365, 423);

            g.setFont(new Font("Arial", Font.BOLD, 18));
            g.drawString("Press ESC to return to menu", 225, 330);
            g.drawString("Press SPACE to start again", 240, 360);
        }
    }

    // Handles keyboard input for starting the round and changing direction.
    public void handleKeyPress(int keyCode) {
        if (gameOver && keyCode == KeyEvent.VK_SPACE) {
            resetGame();
            GameState.state = GameState.PLAYING;
            return;
        }

        if (keyCode == KeyEvent.VK_SPACE && !gameOver) {
            started = true;
            lastMoveTime = System.nanoTime();
            return;
        }

        if (keyCode == KeyEvent.VK_UP) {
            worm.setDirection(Direction.UP);
            started = true;
        } else if (keyCode == KeyEvent.VK_DOWN) {
            worm.setDirection(Direction.DOWN);
            started = true;
        } else if (keyCode == KeyEvent.VK_LEFT) {
            worm.setDirection(Direction.LEFT);
            started = true;
        } else if (keyCode == KeyEvent.VK_RIGHT) {
            worm.setDirection(Direction.RIGHT);
            started = true;
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }
}
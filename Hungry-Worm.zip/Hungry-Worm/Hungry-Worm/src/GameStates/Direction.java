package GameStates;

/**
 * Represents the four movement directions the worm can travel.
 * Each value is used when calculating the next head position and
 * rejecting illegal reversals.
 */
public enum Direction {
    UP, DOWN, LEFT, RIGHT;
}
package GameStates;

import java.awt.Graphics;
import java.awt.event.MouseEvent;

/**
 * Shared lifecycle for every game screen.
 * Each state must define how it updates, renders, and reacts to mouse input.
 */
public interface StateMethods {
    void update();
    void draw(Graphics g);
    void mousePressed(MouseEvent e);
    void mouseReleased(MouseEvent e);
    void mouseMoved(MouseEvent e);
}

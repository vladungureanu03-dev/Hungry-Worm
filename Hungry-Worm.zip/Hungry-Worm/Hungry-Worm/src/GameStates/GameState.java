package GameStates;

/**
 * Keeps track of which screen or mode the game is currently in.
 * The static state value is shared globally so input and rendering
 * code can transition between menu, settings, and gameplay screens.
 */
public enum GameState {
    PLAYING, MENU, SETTINGS, QUIT, GAME_OVER;

    public static GameState state = MENU;
}

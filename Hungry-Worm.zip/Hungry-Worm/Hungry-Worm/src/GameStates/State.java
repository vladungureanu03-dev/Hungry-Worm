package GameStates;

import java.awt.event.MouseEvent;

import GUI.MenuButton;
import Main.Game;

/**
 * Base class shared by menu, settings, and playing states.
 * It owns the reference to the main game object and provides common
 * helpers used by screens that contain clickable UI elements.
 */
public class State {

    protected Game game;

    public State(Game game) {
        this.game = game;
    }

    /**
     * Checks whether the mouse cursor is inside a menu button's bounds.
     */
    public boolean isInButton(MouseEvent e, MenuButton mb) {
        return mb.getBounds().contains(e.getX(), e.getY());
    }

    public Game getGame() {
        return game;
    }
}

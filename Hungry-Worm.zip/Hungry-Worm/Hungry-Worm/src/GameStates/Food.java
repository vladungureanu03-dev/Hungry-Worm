package GameStates;

import java.awt.Point;
import java.util.List;
import java.util.Random;

/**
 * Represents an apple that appears on the board.
 * Gold apples increase score, poisoned apples reduce lives, and normal apples add points.
 */
public class Food {

    private static final long POISON_LIFETIME_NS = 5_000_000_000L;

    private final Random random = new Random();
    private Point position;
    private int seed;
    private int value;
    private long spawnedAt;

    public Food() {
        seed = 4;
        position = new Point(10, 10);
        spawnedAt = System.nanoTime();
    }

    /**
     * Spawns this food at a new random valid location that does not overlap the worm or other food.
     */
    public void respawn(Worm worm, List<Food> others, int cols, int rows) {
        seed = random.nextInt(10);
        switch (seed) {
            case 1 -> value = 5; // golden apple
            case 2, 3 -> value = -1; // poisoned apple
            default -> value = 1; // normal apple
        }
        spawnedAt = System.nanoTime();
        do {
            position = new Point(random.nextInt(cols), random.nextInt(rows));
        } while (worm.contains(position) || takenByOther(others));
    }

    /**
     * Checks whether another food item has already claimed this grid cell.
     */
    private boolean takenByOther(List<Food> others) {
        for (Food f : others) {
            if (f != this && position.equals(f.position)) return true;
        }
        return false;
    }

    /**
     * Poisoned food disappears after a short lifespan.
     */
    public boolean shouldDespawn(long now) {
        return value < 0 && (now - spawnedAt) >= POISON_LIFETIME_NS;
    }

    public Point getPosition() {
        return position;
    }

    public int getSeed() {
        return seed;
    }

    public int getValue() {
        return value;
    }
}
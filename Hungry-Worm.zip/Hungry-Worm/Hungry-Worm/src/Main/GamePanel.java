package Main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import GUI.LoadSave;
import GameStates.GameState;
import Inputs.KeyboardInputs;
import Inputs.MouseInputs;

/**
 * The main Swing panel that renders the active screen and listens for mouse/keyboard input.
 */
public class GamePanel extends JPanel {

    private final Game game;
    private BufferedImage backgroundImage = null;

    public GamePanel(Game game) {
        this.game = game;

        MouseInputs mouseInputs = new MouseInputs(this);
        addMouseListener(mouseInputs);
        addMouseMotionListener(mouseInputs);
        addKeyListener(new KeyboardInputs(this));

        setBackground(new Color(40, 40, 50));
        setPreferredSize(new Dimension(Game.GAME_WIDTH, Game.GAME_HEIGHT));
        setFocusable(true);
        loadGrassBackground();
    }

    /**
     * Loads grass.png from the classpath (falls back to the project folders) and
     * scales it once to the game size, so it is cheap to draw every frame.
     */
    private void loadGrassBackground() {
        try {
            BufferedImage raw = LoadSave.GetSpriteAtlas(LoadSave.GRASS);
            BufferedImage scaled = new BufferedImage(
                    Game.GAME_WIDTH, Game.GAME_HEIGHT, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2 = scaled.createGraphics();
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2.drawImage(raw, 0, 0, Game.GAME_WIDTH, Game.GAME_HEIGHT, null);
            g2.dispose();
            backgroundImage = scaled;
        } catch (RuntimeException e) {
            backgroundImage = null;
            System.out.println("Background image not loaded: " + LoadSave.GRASS);
        }
    }

    /**
     * Allows a custom background path to be supplied for alternate image setups.
     */
    public void setBackgroundImagePath(String imagePath) {
        if (imagePath == null || imagePath.trim().isEmpty()) {
            backgroundImage = null;
            return;
        }

        try {
            backgroundImage = ImageIO.read(new File(imagePath));
        } catch (IOException e) {
            backgroundImage = null;
            System.out.println("Background image not loaded: " + imagePath);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), null);
        }

        // Draw the currently active state: menu, settings, or gameplay.
        switch (GameState.state) {
            case MENU:
                game.getMenu().draw(g);
                break;
            case PLAYING:
                game.getPlaying().draw(g);
                break;
            case SETTINGS:
                game.getSettings().draw(g);
                break;
            case GAME_OVER:
                game.getPlaying().draw(g);
                break;
            default:
                break;
        }
    }

    public Game getGame() {
        return game;
    }
}
package Main;

import GameStates.GameState;
import GameStates.Menu;
import GameStates.Playing;
import GameStates.Settings;

/**
 * Main game engine. It owns the screen states, runs the update loop, and
 * coordinates when the menu, gameplay, and settings screens are active.
 */
public class Game implements Runnable {

    public static final float SCALE = 1.5f;
    public static final int GAME_WIDTH = 800;
    public static final int GAME_HEIGHT = 600;
    private static final int FPS = 60;

    private final GamePanel panel;
    private final Menu menu;
    private final Playing playing;
    private final Settings settings;
    private Thread gameThread;

    public Game() {
        menu = new Menu(this);
        playing = new Playing(this);
        settings = new Settings(this);
        panel = new GamePanel(this);
        new GameWindow(panel);
        panel.requestFocus();
        startGameLoop();
    }

    /**
     * Starts the background game loop thread.
     */
    private void startGameLoop() {
        gameThread = new Thread(this, "game-loop");
        gameThread.start();
    }

    /**
     * Advances only the active screen based on the current GameState.
     */
    private void update() {
        switch (GameState.state) {
            case MENU:
                menu.update();
                break;
            case PLAYING:
                playing.update();
                break;
            case QUIT:
                System.exit(0);
                break;
            default:
                break;
        }
    }

    @Override
    public void run() {
        final double frameTime = 1_000_000_000.0 / FPS;
        long last = System.nanoTime();
        double delta = 0;

        while (true) {
            long now = System.nanoTime();
            delta += (now - last) / frameTime;
            last = now;

            if (delta >= 1) {
                update();
                panel.repaint();
                delta--;
            } else {
                try {
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                    return;
                }
            }
        }
    }

    public Menu getMenu() {
        return menu;
    }

    public Settings getSettings() {
        return settings;
    }

    public Playing getPlaying() {
        return playing;
    }

    /**
     * Starts a fresh round from the menu.
     */
    public void startGame() {
        playing.resetGame();
        GameState.state = GameState.PLAYING;
    }

    /**
     * Restarts the round after a game-over event.
     */
    public void restartGame() {
        playing.resetGame();
        GameState.state = GameState.PLAYING;
    }

    public static void main(String[] args) {
        new Game();
    }
}
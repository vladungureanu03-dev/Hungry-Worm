package Main;

import javax.swing.JFrame;

/**
 * Wraps the Swing window that hosts the game panel.
 */
public class GameWindow {

    private final JFrame frame;

    public GameWindow(GamePanel panel) {
        frame = new JFrame("Hungry Worm");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        frame.setResizable(false);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}

# Hungry Worm

A simple worm game. Move the worm, eat apples, and don't run out of lives.

## What you need

- Java (JDK 17 or newer) installed
- A Java program to open the project in, such as VS Code, IntelliJ IDEA or Eclipse

## How to open and start the game

1. Unzip the project.
2. Open the `Hungry-Worm` folder in your Java program.
   - VS Code: File > Open Folder (install the "Extension Pack for Java" first)
   - IntelliJ: File > Open
   - Eclipse: File > Import > Maven > Existing Maven Projects
3. Open the file `src/Main/Game.java`.
4. Run it. In VS Code or IntelliJ, click the Run button next to `main`.
   In Eclipse, right-click the project > Run As > Java Application.

The game window opens right away.

## How to play

- Click **Start Game** in the menu (or press SPACE).
- Use the arrow keys to move the worm.
- Red apple: +1 point. Yellow apple: +5 points.
- Purple apple: poison! You lose a life. It disappears after 5 seconds.
- Hitting a wall or getting too hungry costs a life. You have 3 lives.
- **Settings** lets you change the speed, the number of apples and the field size.
- When the game is over, click **Restart** or press SPACE. Press ESC to go back to the menu.

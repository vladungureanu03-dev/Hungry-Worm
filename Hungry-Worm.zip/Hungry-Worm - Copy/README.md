# Hungry-Worm

Run the game from this project folder with `mvn exec:java`. The main class is
`Main.Game` (Java package and class names are case-sensitive).